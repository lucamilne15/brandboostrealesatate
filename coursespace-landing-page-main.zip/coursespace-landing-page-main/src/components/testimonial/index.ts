export { default as TestimonialItem } from './testimonial-item'
