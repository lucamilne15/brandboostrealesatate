export interface SocialLink {
  name: string
  link: string
  icon?: string
}
