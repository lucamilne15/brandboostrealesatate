export interface Navigation {
  label: string
  path: string
}
